# Welcome to Osquerybeat 8.1.3

Osquerybeat is a beat implementation for osquery.

## Getting Started

To get started with Osquerybeat, you need to set up Elasticsearch on
your localhost first. After that, start Osquerybeat with:

     ./osquerybeat -c osquerybeat.yml -e

This will start Osquerybeat and send the data to your Elasticsearch
instance. To load the dashboards for Osquerybeat into Kibana, run:

    ./osquerybeat setup -e

For further steps visit the
[Quick start](https://www.elastic.co/guide/en/beats/osquerybeat/8.1/osquerybeat-installation-configuration.html) guide.

## Documentation

Visit [Elastic.co Docs](https://www.elastic.co/guide/en/beats/osquerybeat/8.1/index.html)
for the full Osquerybeat documentation.

## Release notes

https://www.elastic.co/guide/en/beats/libbeat/8.1/release-notes-8.1.3.html
