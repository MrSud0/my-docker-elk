# Welcome to Apm-Server 8.1.3

Elastic APM Server

## Getting Started

To get started with Apm-Server, you need to set up Elasticsearch on
your localhost first. After that, start Apm-Server with:

     ./apm-server -c apm-server.yml -e

This will start Apm-Server and send the data to your Elasticsearch
instance. To load the dashboards for Apm-Server into Kibana, run:

    ./apm-server setup -e

For further steps visit the
[Quick start](https://www.elastic.co/guide/en/beats/apm-server/master/apm-server-installation-configuration.html) guide.

## Documentation

Visit [Elastic.co Docs](https://www.elastic.co/guide/en/beats/apm-server/master/index.html)
for the full Apm-Server documentation.

## Release notes

https://www.elastic.co/guide/en/beats/libbeat/master/release-notes-8.1.3.html
